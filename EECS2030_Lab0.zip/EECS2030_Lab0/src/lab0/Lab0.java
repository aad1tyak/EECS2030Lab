package lab0;

import java.util.ArrayList;

/**
 * Lab0 class containing three methods for various computational tasks.
 * 
 * @author Sukhwant Sagar
 */
public class Lab0 {

	//First Method
    public static double calculateBMI(double weight, double height) {
    	// Handle exceptional cases for height
        
        
        // Handle exceptional cases for weight
        
        
        // Calculate BMI using the formula: weight / (height²)
        
        
        // Handle potential overflow/underflow
        
        
        // Round to one decimal place and return bmi
    	
    	
        
    }

  //Second Method
    public static String findLongestWord(ArrayList<String> words) {
        // Handle empty list
        
        
            
        // Iterate through all words to find the longest, Handle null strings by treating them as empty and
    	// Update longest word if current word is longer
        
        
       //Return the longest word 
    }

  //Third Method
    public static int countVowels(String text) {
        // Handle null input
       
        
        // Convert to lowercase for case-insensitive comparison
        
        
        
        // Count vowels by checking each character
       
        //Return Vowel count
        
    }
}