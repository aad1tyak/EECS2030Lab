package lab3;

/**
 * Represents a scoring format for a sports league.
 * This class is composed within a League (composition relationship).
 * Constructors are private - objects must be created using static factory methods.
 * 
 * @author Dr. Sukhwant Sagar
 * @since Fall 2025
 */
class ScoringFormat {
    //attributes

    /**
     * Private constructor to create a ScoringFormat.
     * Users must use static factory methods to create instances.
     * 
     * @param formatName the name of the scoring format
     * @param touchdownPoints points awarded for touchdowns
     * @param receptionPoints points awarded per reception
     * @param yardsPerPoint yards needed per point
     */
    
	

    /**
     * Private copy constructor to create a deep copy of a ScoringFormat.
     * Used internally for composition relationships.
     * 
     * @param other the ScoringFormat to copy
     */
    
	
    
    /**
     * Package-private method to create a copy.
     * This is used by League class for composition relationship.
     * 
     * @param other the ScoringFormat to copy
     * @return a new deep copy of the ScoringFormat
     */
    

    /**
     * Static factory method to create a Standard scoring format.
     * Standard: 6 points per TD, 0 points per reception, 0.1 yards per point
     * 
     * @return a new ScoringFormat with Standard settings
     */
    

    /**
     * Static factory method to create a PPR (Points Per Reception) scoring format.
     * PPR: 6 points per TD, 1 point per reception, 0.1 yards per point
     * 
     * @return a new ScoringFormat with PPR settings
     */
    

    /**
     * Static factory method to create a Half-PPR scoring format.
     * Half-PPR: 6 points per TD, 0.5 points per reception, 0.1 yards per point
     * 
     * @return a new ScoringFormat with Half-PPR settings
     */
    

    // Getters and Setters
   

    
}

/**
 * Represents an athlete in a sports league.
 * Athletes can be part of team rosters (aggregation relationship).
 *  
 */
class Athlete {
    
	//Attributes
	
    /**
     * Overloaded constructor to create an Athlete.
     * 
     * @param athleteId unique identifier for the athlete
     * @param firstName athlete's first name
     * @param lastName athlete's last name
     * @param position athlete's position (QB, RB, WR, etc.)
     * @param proTeam athlete's professional team
     */
    

    /**
     * Copy constructor to create a deep copy of an Athlete.
     * 
     * @param other the Athlete to copy
     */
    

    /**
     * Static factory method to create an Athlete.
     * 
     * @param athleteId unique identifier for the athlete
     * @param firstName athlete's first name
     * @param lastName athlete's last name
     * @param position athlete's position
     * @param proTeam athlete's professional team
     * @return a new Athlete instance
     */
    

    // Getters and Setters
  


}

/**
 * Represents a team in a league.
 * Teams have athletes (aggregation) and game statistics (composition).
 * 
 */
class Team {
	
   //Attributes

    /**
     * Overloaded constructor to create a Team.
     * 
     * @param teamId unique identifier for the team
     * @param teamName name of the team
     * @param ownerName name of the team owner
     * @param logoColor team's logo color
     */
   

    /**
     * Copy constructor to create a deep copy of a Team.
     * 
     * @param other the Team to copy
     */
    

    /**
     * Static factory method to create a Team.
     * 
     * @param teamId unique identifier for the team
     * @param teamName name of the team
     * @param ownerName name of the team owner
     * @param logoColor team's logo color
     * @return a new Team instance
     */
   
    // Getters and Setters
    

}

/**
 * Represents a sports league.
 * A league has a scoring format (composition) and teams (aggregation).
 * */
public class League {
	
    //Attributes

    /**
     * Default constructor to create a League with default values.
     * leagueId = "L000",leagueName = "Default League",commissionerName = "Commissioner",season = 2025,new scoringFormat, new ArrayList Team,maxTeams = 10
     */
    

    /**
     * Overloaded constructor to create a League.
     * 
     * @param leagueId unique identifier for the league
     * @param leagueName name of the league
     * @param commissionerName name of the league commissioner
     * @param season the season year
     * @param scoringFormat the scoring format for the league (composition)
     * @param maxTeams maximum number of teams allowed
     */
   

    /**
     * Copy constructor to create a deep copy of a League.
     * 
     * @param other the League to copy
     */
    

    /**
     * Static factory method to create a League.
     * 
     * @param leagueId unique identifier for the league
     * @param leagueName name of the league
     * @param commissionerName name of the league commissioner
     * @param season the season year
     * @param scoringFormat the scoring format for the league
     * @param maxTeams maximum number of teams allowed
     * @return a new League instance
     */
    

    // Getters and Setters
   

    /**
     * Gets a copy of the scoring format (composition - return deep copy).
     * 
     * @return a deep copy of the scoring format
     */
   

    /**
     * Sets the scoring format with a deep copy (composition).
     * 
     * @param scoringFormat the new scoring format
     */
    


}