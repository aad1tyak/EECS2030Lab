package lab4;

/**
* SpaceMission - Main class containing all space mission related classes.
* This file demonstrates inheritance, composition, and aggregation relationships.
* 
* @author Dr. Sukhwant Sagar
*/
public class SpaceMission {
   // Empty main class - all functionality is in the inner classes below
}

/**
 * PowerSystem class - represents the power management system of a spacecraft.
 * This class demonstrates COMPOSITION - it cannot exist without a Spacecraft.
 * The PowerSystem manages all energy-related operations including battery management,
 * solar panel efficiency tracking, and power consumption monitoring.
 * 
 * @author Dr. Sukhwant Sagar
 */
class PowerSystem {
    //Attributes
    
    /**
     * Overloaded constructor that initializes all fields of the PowerSystem.
     * 
     * @param batteryLevel the current battery level as a percentage (0-100)
     * @param solarPanelEfficiency the efficiency of solar panels as a percentage (0-100)
     * @param powerConsumptionRate the rate of power consumption in kilowatts
     * @param maxCapacity the maximum battery capacity in kilowatt-hours
     */
    
	
	
    
    /**
     * Copy constructor that creates a deep copy of another PowerSystem object.
     * This ensures that modifications to the original do not affect the copy.
     * 
     * @param other the PowerSystem object to copy
     */
   
	
	
	
    /**
     * Gets the current battery level.
     * 
     * @return the battery level as a percentage
     */
   
	
	
    
    /**
     * Sets the battery level to a new value.
     * 
     * @param batteryLevel the new battery level as a percentage
     */


	
    /**
     * Gets the solar panel efficiency.
     * 
     * @return the solar panel efficiency as a percentage
     */


	
    /**
     * Sets the solar panel efficiency to a new value.
     * 
     * @param solarPanelEfficiency the new solar panel efficiency as a percentage
     */


	
    /**
     * Gets the power consumption rate.
     * 
     * @return the power consumption rate in kilowatts
     */


	
    
    /**
     * Sets the power consumption rate to a new value.
     * 
     * @param powerConsumptionRate the new power consumption rate in kilowatts
     */


    
    /**
     * Gets the maximum battery capacity.
     * 
     * @return the maximum capacity in kilowatt-hours
     */


	
    
    /**
     * Sets the maximum battery capacity to a new value.
     * 
     * @param maxCapacity the new maximum capacity in kilowatt-hours
     */


	
    /**
     * Charges the battery by a specified amount using solar panels or external power sources.
     * The battery level cannot exceed the maximum capacity to prevent overcharging damage.
     * Formula: batteryLevel = minimum of (batteryLevel + amount, maxCapacity)
     * 
     * @param amount the amount of charge to add as a percentage
     */


	
    
    /**
     * Consumes power from the battery to operate spacecraft systems and equipment.
     * The battery level cannot go below zero, representing complete power depletion.
     * Formula: batteryLevel = maximum of (batteryLevel - amount, 0)
     * 
     * @param amount the amount of power to consume as a percentage
     */


	
    
    /**
     * Checks the current power status based on battery level thresholds for mission safety.
     * Returns status classification to indicate operational readiness of the spacecraft.
     * Status Rules: >75% = Optimal, >25% = Moderate, ≤25% = Critical
     * 
     * @return "Optimal" if battery > 75%, "Moderate" if battery > 25%, "Critical" otherwise
     */


	
    
    /**PROVIDED: 
     * Displays comprehensive power system information in a formatted string for monitoring.
     * Provides complete overview of battery status, efficiency, consumption, and capacity metrics.
     * 
     * @return a formatted string containing all power system details
     */
    public String displayPowerInfo() {
        return String.format("PowerSystem [Battery: %.2f%%, Solar Efficiency: %.2f%%, " +
                           "Consumption: %.2fkW, Max Capacity: %.2fkWh]",
                           batteryLevel, solarPanelEfficiency, powerConsumptionRate, maxCapacity);
    }
}

/**
 * Crew class - represents the crew members assigned to a spacecraft.
 * This class demonstrates AGGREGATION - it can exist independently of Spacecraft.
 * Crew members can be reassigned to different missions and continue to exist
 * even after a particular spacecraft mission ends.
 * 
 * @author Dr. Sukhwant Sagar
 * 
 */
class Crew {
    //Attributes
    
    /**
     * Overloaded constructor that initializes all fields of the Crew.
     * 
     * @param crewMembers a comma-separated string of crew member names
     * @param crewSize the number of crew members
     * @param missionRole the primary role of the crew (e.g., "Pilot", "Engineer")
     */
    
	
    
    /**
     * Copy constructor that creates a copy of another Crew object.
     * 
     * @param other the Crew object to copy
     */


	
    
    /**
     * Gets the crew members as a comma-separated string.
     * 
     * @return the crew members string
     */


	
    /**
     * Sets the crew members string.
     * 
     * @param crewMembers the new crew members string
     */


	
    /**
     * Gets the crew size.
     * 
     * @return the number of crew members
     */


	
    /**
     * Sets the crew size.
     * 
     * @param crewSize the new crew size
     */


	
    
    /**
     * Gets the mission role of the crew.
     * 
     * @return the mission role
     */


	
    /**
     * Sets the mission role of the crew.
     * 
     * @param missionRole the new mission role
     */
    
	

    
    /**
     * Assigns a new member to the crew by appending their name to the crew list and incrementing the total count.
     * Handles comma-separated formatting automatically, ensuring proper string structure whether the crew is empty
     * or already populated.
     * Formula: crewSize = crewSize + 1
     * 
     * @param memberName the name of the member to assign
     */
    
	

    
    /**
     * Removes a member from the crew by deleting their name from the crew list and decrementing the total count.
     * Cleans up string formatting by removing extra commas and whitespace to maintain proper comma-separated structure.
     * Formula: crewSize = max(crewSize - 1, 0)
     * 
     * @param memberName the name of the member to remove
     */


	
    /**
     * Gets the current count of crew members.
     * 
     * @return the crew size
     */



    
    /**PROVIDED: 
     * Displays comprehensive crew information in a formatted string.
     * 
     * @return a formatted string containing all crew details
     */
    public String displayCrewInfo() {
        return String.format("Crew [Members: %s, Size: %d, Role: %s]",
                           crewMembers, crewSize, missionRole);
    }
}

/**
 * Spacecraft class - the superclass for all space missions.
 * Demonstrates COMPOSITION with PowerSystem and AGGREGATION with Crew.
 * This class serves as the parent class for specialized mission types
 * like RoverMission and SatelliteMission.
 * 
 * <p>Composition: PowerSystem is created internally and cannot exist without Spacecraft.
 * Aggregation: Crew is passed as a parameter and can exist independently.</p>
 * 
 * @author Dr. Sukhwant Sagar
 */
class Spacecraft {
   //Attributes
    
    /**
     * Default constructor that initializes all fields to default values.
     * Creates a new PowerSystem internally (composition).
     * Crew is set to null initially (aggregation).
     */
    
	
    
    /**
     * Overloaded constructor that initializes all fields with specified values.
     * Creates a new PowerSystem internally (composition).
     * Accepts a Crew reference as a parameter (aggregation).
     * 
     * @param missionID the unique mission identifier
     * @param launchDate the scheduled launch date
     * @param fuelCapacity the fuel capacity in metric tons
     * @param currentStatus the current operational status
     * @param missionDuration the mission duration in days
     * @param crew the crew assigned to this mission (can be null)
     */


	
    
    /**
     * Copy constructor that creates a copy of another Spacecraft.
     * Performs deep copy for PowerSystem (composition).
     * Performs shallow copy for Crew (aggregation).
     * 
     * @param other the Spacecraft object to copy
     */


	
    
    /**
     * Gets the mission ID.
     * 
     * @return the mission identifier
     */


	
    /**
     * Sets the mission ID.
     * 
     * @param missionID the new mission identifier
     */


	
    
    /**
     * Gets the launch date.
     * 
     * @return the launch date
     */


	
    
    /**
     * Sets the launch date.
     * 
     * @param launchDate the new launch date
     */


	
    
    /**
     * Gets the fuel capacity.
     * 
     * @return the fuel capacity in metric tons
     */


	
    
    /**
     * Sets the fuel capacity.
     * 
     * @param fuelCapacity the new fuel capacity in metric tons
     */


	
    
    /**
     * Gets the current operational status.
     * 
     * @return the current status
     */


	
    
    /**
     * Sets the current operational status.
     * 
     * @param currentStatus the new status
     */


	
    
    /**
     * Gets the mission duration.
     * 
     * @return the mission duration in days
     */


	
    
    /**
     * Sets the mission duration.
     * 
     * @param missionDuration the new mission duration in days
     */


	
    
    /**
     * Gets the power system of this spacecraft.
     * Note: No setter is provided as PowerSystem is composed (cannot be replaced).
     * 
     * @return the PowerSystem object
     */


	
    
    /**
     * Gets the crew assigned to this spacecraft.
     * 
     * @return the Crew object, or null if no crew is assigned
     */


	
    
    /**
     * Sets or reassigns the crew for this spacecraft.
     * This demonstrates aggregation - crew can be reassigned.
     * 
     * @param crew the new Crew to assign
     */


	
    
    /**
     * Launches the spacecraft by changing its status to "Active".
     */


	
    
    /**PROVIDED: 
     * Transmits data from the spacecraft.
     * Prints a message indicating data transmission.
     */
    public void transmitData() {
        System.out.println("Transmitting data from mission " + missionID);
    }
    
    /**
     * Calculates the total distance based on mission duration.
     * Simple calculation: duration * 1000 km.
     * 
     * @return the calculated distance in kilometers
     */


    
    /**
     * Refuels the spacecraft by adding to the fuel capacity.
     * 
     * @param amount the amount of fuel to add in metric tons
     */
    public void refuel(double amount) {
        fuelCapacity += amount;
    }
    
    /**PROVIDED: 
     * Displays comprehensive information about the spacecraft.
     * Includes spacecraft details, power system info, and crew info.
     * 
     * @return a formatted string containing all spacecraft information
     */
    public String displayInfo() {
        String crewInfo = (crew != null) ? crew.displayCrewInfo() : "No crew assigned";
        return String.format("Spacecraft [ID: %s, Launch: %s, Fuel: %.2f, Status: %s, " +
                           "Duration: %d days]\n%s\n%s",
                           missionID, launchDate, fuelCapacity, currentStatus, 
                           missionDuration, powerSystem.displayPowerInfo(), crewInfo);
    }
}

/**
 * RoverMission class - subclass of Spacecraft for planetary surface exploration.
 * Extends Spacecraft and adds rover-specific attributes and behaviors.
 * Inherits composition relationship with PowerSystem and aggregation with Crew.
 * 
 * @author Dr. Sukhwant Sagar
 */
class RoverMission {
   //Attributes
    
    /**
     * Overloaded constructor that initializes all fields including inherited ones.
     * Uses super() to call the parent constructor for Spacecraft fields.
     * 
     * @param missionID the unique mission identifier
     * @param launchDate the scheduled launch date
     * @param fuelCapacity the fuel capacity in metric tons
     * @param currentStatus the current operational status
     * @param missionDuration the mission duration in days
     * @param crew the crew assigned to this mission
     * @param planetName the name of the planet to explore
     * @param terrainType the type of terrain (e.g., "Rocky", "Sandy")
     * @param samplesCollected the number of samples collected
     * @param maxSpeed the maximum speed in km/h
     */
    
	
	
    
    /**
     * Copy constructor that creates a copy of another RoverMission.
     * Uses super() to copy Spacecraft fields (including deep copy of PowerSystem).
     * 
     * @param other the RoverMission object to copy
     */


	
    /**
     * Gets the planet name.
     * 
     * @return the name of the planet
     */


	
    
    /**
     * Sets the planet name.
     * 
     * @param planetName the new planet name
     */


	
    
    /**
     * Gets the terrain type.
     * 
     * @return the terrain type
     */


	
    
    /**
     * Sets the terrain type.
     * 
     * @param terrainType the new terrain type
     */


	
    
    /**
     * Gets the number of samples collected.
     * 
     * @return the samples collected count
     */


	
    
    /**
     * Sets the number of samples collected.
     * 
     * @param samplesCollected the new samples count
     */


	
    
    /**
     * Gets the maximum speed of the rover.
     * 
     * @return the maximum speed in km/h
     */


	
    
    /**
     * Sets the maximum speed of the rover.
     * 
     * @param maxSpeed the new maximum speed in km/h
     */


	
    
    /**
     * Collects a sample and increments the samples collected count.
     */


	
    
    /**
     * PROVIDED: Analyzes the terrain of the current location.
     * Prints analysis information about the terrain type and planet.
     */
    public void analyzeTerrain() {
        System.out.println("Analyzing " + terrainType + " terrain on " + planetName);
    }
    
    /**
     * PROVIDED: Deploys scientific instruments on the planetary surface.
     * Prints deployment information.
     */
    public void deployInstruments() {
        System.out.println("Deploying scientific instruments on " + planetName);
    }
    
    /**
     * PROVIDED: Drives the rover a specified distance.
     * Prints information about the distance traveled and maximum speed.
     * 
     * @param distance the distance to drive in kilometers
     */
    public void driveDistance(double distance) {
        System.out.println("Rover driving " + distance + " km at max speed " + maxSpeed + " km/h");
    }
    
    /**
     * Displays comprehensive information about the rover mission.
     * Overrides the parent method to include rover-specific details.
     * 
     * @return a formatted string containing all rover mission information
     */
    
    
    
}

/**
 * SatelliteMission class - subclass of Spacecraft for orbital observation.
 * Extends Spacecraft and adds satellite-specific attributes and behaviors.
 * Inherits composition relationship with PowerSystem and aggregation with Crew.
 * 
 * @author Dr. Sukhwant Sagar
 */
class SatelliteMission {
    //Attributes
    
    /**
     * Overloaded constructor that initializes all fields including inherited ones.
     * Uses super() to call the parent constructor for Spacecraft fields.
     * 
     * @param missionID the unique mission identifier
     * @param launchDate the scheduled launch date
     * @param fuelCapacity the fuel capacity in metric tons
     * @param currentStatus the current operational status
     * @param missionDuration the mission duration in days
     * @param crew the crew assigned to this mission
     * @param orbitAltitude the orbit altitude in kilometers
     * @param orbitType the type of orbit (e.g., "Geostationary", "Polar")
     * @param resolutionQuality the image resolution quality in meters per pixel
     * @param coverageArea the coverage area in square kilometers
     */
   
	
	
    
    /**
     * Copy constructor that creates a copy of another SatelliteMission.
     * Uses super() to copy Spacecraft fields (including deep copy of PowerSystem).
     * 
     * @param other the SatelliteMission object to copy
     */


	
	
    /**
     * Gets the orbit altitude.
     * 
     * @return the orbit altitude in kilometers
     */


	
    
    /**
     * Sets the orbit altitude.
     * 
     * @param orbitAltitude the new orbit altitude in kilometers
     */


	
    
    /**
     * Gets the orbit type.
     * 
     * @return the orbit type
     */


	
    
    /**
     * Sets the orbit type.
     * 
     * @param orbitType the new orbit type
     */


	
    
    /**
     * Gets the image resolution quality.
     * 
     * @return the resolution quality in meters per pixel
     */


	
    
    /**
     * Sets the image resolution quality.
     * 
     * @param resolutionQuality the new resolution quality in meters per pixel
     */


	
    
    /**
     * Gets the coverage area.
     * 
     * @return the coverage area in square kilometers
     */


	
    
    /**
     * Sets the coverage area.
     * 
     * @param coverageArea the new coverage area in square kilometers
     */


	
    
    /**PROVIDED: 
     * Captures an image with the satellite's imaging system.
     * Prints information about the image resolution.
     */
    public void captureImage() {
        System.out.println("Capturing image at " + resolutionQuality + "m resolution");
    }
    
    /**
     * PROVIDED: Adjusts the satellite's orbit.
     * Prints information about the orbit type and altitude.
     */
    public void adjustOrbit() {
        System.out.println("Adjusting " + orbitType + " orbit at " + orbitAltitude + " km");
    }
    
    /**
     * PROVIDED: Scans a specified region using the satellite's sensors.
     * Prints information about the coverage area.
     */
    public void scanRegion() {
        System.out.println("Scanning coverage area of " + coverageArea + " sq km");
    }
    
    /**PROVIDED: 
     * Transmits collected images back to ground stations.
     * Prints transmission information with the mission ID.
     */
    public void transmitImages() {
        System.out.println("Transmitting images from satellite " + getMissionID());
    }
    
    /**
     * Displays comprehensive information about the satellite mission.
     * Overrides the parent method to include satellite-specific details.
     * 
     * @return a formatted string containing all satellite mission information
     */
   
}
